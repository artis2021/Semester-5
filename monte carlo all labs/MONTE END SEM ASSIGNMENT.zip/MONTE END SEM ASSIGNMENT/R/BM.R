# install.packages("shiny")

library(shiny)
library(shinythemes)
library(pracma)

ui <- fluidPage(theme=shinytheme("yeti"),
  
  titlePanel("Generate a brownian motion"),
  
  sidebarLayout(
    
      sidebarPanel(
        sliderInput(inputId = "s0",
                    label = "S[0]:",
                    min = 1,
                    max = 50,
                    value = 30),
        
        sliderInput(inputId = "drift",
                    label = "\U03bc :",
                    min = 0,
                    max = 50,
                    value = 30, round = TRUE, step = 0.01),
        
        sliderInput(inputId = "volatility",
                    label = "\U03C3 :",
                    min = 0,
                    max = 50,
                    value = 30, round = TRUE, step = 0.01),
        
        sliderInput(inputId = "time",
                    label = "Time(T):",
                    min = 1,
                    max = 50,
                    value = 30),
        
        sliderInput(inputId = "n",
                    label = "Time Steps",
                    min = 1,
                    max = 10000,
                    value = 1000),
        
        sliderInput(inputId = "N",
                    label = "No. of Paths",
                    min = 1,
                    max = 100,
                    value = 10),
        
        selectInput(inputId = "type", 
                    label = "Type of Brownian Motion:",
                    choices = list("Brownian Motion" = 1, "Geometric Brownian Motion" = 2),
                    multiple = FALSE)
        
      ),
      
      mainPanel(
        
        plotOutput(outputId = "plot"),
        h5("Created by Arti Sahu  (Roll No.- 200123011)")
        
      )
  )
)

server <- function(input, output) {
  
  output$plot <- renderPlot({
    u <- input$drift
    sig <- input$volatility
    choice <- input$type
    Time <- input$time
    steps <- input$n
    t <- Time/steps
    Times <- linspace(0,Time,steps+1)
    N <- input$N

    cl <- rainbow(N)
    #Brownian Motion
    if (choice == 1) {
      curr <- 0
      Price <- c(curr)
      for (i in 1:steps)
      {
        curr <- curr+u*t + sig*sqrt(t)*rnorm(1)
        Price <- append(Price,curr)
      }
      plot(Times, Price, type='l', col = cl[1])
      par(new=TRUE)
      
      for (j in 2:N) {
        curr <- 0
        Price <- c(curr)
        for (i in 1:steps)
        {
          curr <- curr+u*t + sig*sqrt(t)*rnorm(1)
          Price <- append(Price,curr)
        }
      
        plot(Times, Price, type='l', col = cl[j], ylab="",yaxt="n")
        par(new=TRUE)
      }
    }
    
    #Geometric Brownian Motion
    if (choice == 2) {
      curr <- input$s0
      Price <- c(curr)
      for (i in 1:steps)
      {
        curr <- curr*(exp((u - sig^2/2)*t + sig*sqrt(t)*rnorm(1)))
        Price <- append(Price,curr)
      }
      
      plot(Times, Price, type='l', col=cl[1])
      par(new=TRUE)
      
      for (j in 2:N) {
        curr <- input$s0
        Price <- c(curr)
        for (i in 1:steps)
        {
          curr <- curr*(exp((u - sig^2/2)*t + sig*sqrt(t)*rnorm(1)))
          Price <- append(Price,curr)
        }
      
        plot(Times, Price, type='l', col=cl[j], ylab="",yaxt="n")
        par(new=TRUE)
      }
    }
  })
  
}


shinyApp(ui = ui, server = server)