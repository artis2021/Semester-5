#include "types.h"
#include "stat.h"
#include "user.h"

int main(){

	printf(1, "First Test");

	exit();

}