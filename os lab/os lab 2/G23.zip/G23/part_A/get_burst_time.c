#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  printf(1,"%d",get_burst_time());
  exit();
}
